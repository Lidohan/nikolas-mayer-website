import { mkdir, rm, writeFile } from "node:fs/promises";

const dist = new URL("./dist/", import.meta.url);
await rm(dist, { recursive: true, force: true });
await mkdir(dist, { recursive: true });

const css = `
:root{--bg:#f3f0e9;--surface:#fbfaf7;--ink:#14202c;--muted:#66727d;--line:#d9d7d1;--accent:#1f4f6b;--max:1180px}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:var(--bg);color:var(--ink);font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;font-size:17px;line-height:1.65}
a{color:inherit}.container{width:min(calc(100% - 36px),var(--max));margin-inline:auto}.nav{border-bottom:1px solid var(--line);background:rgba(243,240,233,.96);position:sticky;top:0;z-index:10}.navin{min-height:74px;display:flex;align-items:center;justify-content:space-between;gap:24px}.brand{font-family:Georgia,serif;font-weight:700;font-size:1.2rem;text-decoration:none}.links{display:flex;gap:20px;flex-wrap:wrap}.links a{text-decoration:none;color:var(--muted);font-size:.92rem}.hero{padding:110px 0 86px}.eyebrow{margin:0 0 14px;color:var(--accent);font-size:.78rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase}
h1,h2,h3{font-family:Georgia,"Times New Roman",serif;line-height:1.08;letter-spacing:-.025em}h1{font-size:clamp(3rem,7vw,6.4rem);margin:0;max-width:12ch}h2{font-size:clamp(2.2rem,4vw,4rem);margin:0 0 22px;max-width:16ch}h3{font-size:1.4rem;margin:0 0 10px}.lead{font-size:clamp(1.22rem,2vw,1.58rem);color:var(--muted);max-width:820px}.section{padding:82px 0;border-top:1px solid var(--line)}.grid2{display:grid;grid-template-columns:1.05fr .95fr;gap:58px}.grid3{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}.card{background:var(--surface);border:1px solid var(--line);border-radius:20px;padding:26px}.career{padding:24px 0;border-bottom:1px solid var(--line)}.period{color:var(--accent);font-size:.84rem;font-weight:800}.muted{color:var(--muted)}.button{display:inline-block;margin-top:12px;padding:11px 18px;border:1px solid var(--line);border-radius:999px;text-decoration:none;font-weight:700}.footer{padding:54px 0;color:var(--muted);border-top:1px solid var(--line)}.preview{position:fixed;left:50%;bottom:14px;transform:translateX(-50%);background:#fff3c4;border:1px solid #dbc873;border-radius:999px;padding:7px 13px;font-size:12px;font-weight:750}
ul{padding-left:1.2rem}@media(max-width:820px){.grid2,.grid3{grid-template-columns:1fr}.links{display:none}.hero{padding-top:70px}body{font-size:16px}}
`;

const nav = (prefix="") => `
<nav class="nav"><div class="container navin">
<a class="brand" href="${prefix}/">Nikolas Mayer</a>
<div class="links">
<a href="${prefix}/about/">About</a><a href="${prefix}/career/">Career</a><a href="${prefix}/publications/">Publications</a><a href="${prefix}/videos/">Public analysis</a><a href="/cs/">Česky</a>
</div></div></nav>`;

const head = (title, desc, canonical) => `<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${title}</title><meta name="description" content="${desc}">
<meta name="robots" content="noindex,follow">
<link rel="canonical" href="https://nikolasmayer.com${canonical}">
<style>${css}</style>
</head><body>${nav("")}`;

const foot = `</main><footer class="footer"><div class="container">Nikolas Mayer · Economics · Financial markets · European policy</div></footer><div class="preview">DEMO · CRAWL ALLOWED · NOINDEX</div></body></html>`;

async function page(path, title, desc, body) {
  const dir = new URL(`./dist${path}`, import.meta.url);
  await mkdir(dir, { recursive: true });
  await writeFile(new URL("index.html", dir), head(title, desc, path) + `<main>${body}` + foot);
}

const career = [
["2025–present","European Parliament","Administrator / economic and budgetary policy adviser","Economic, financial-services and budgetary policy work, including legislative analysis, briefings, amendments and assessment of European Commission proposals."],
["Jun 2022–Apr 2025","European Commission — DG ECFIN","Economic Analyst — Czech Republic, Poland and Slovakia","Macroeconomic forecasting, country surveillance, fiscal analysis and Recovery and Resilience Facility work for Central European economies."],
["Feb 2021–Jun 2022","European Central Bank","Financial Stability / Macroprudential Policy Analyst","Analysis of macroprudential policy, bank resilience, lending behaviour and the interaction between capital requirements and credit conditions."],
["Jul 2019–Feb 2021","European Central Bank","Market Operations Analyst — Bond and International Markets","Sovereign bond, foreign-exchange and international market analysis relevant to monetary-policy implementation and reserve management."],
["Jul 2016–Jun 2019","European Central Bank","Supervisory Data Research Analyst","Supervisory banking data, data-quality processes and analytical work within the Single Supervisory Mechanism environment."],
["Jul 2015–Jul 2016","European Systemic Risk Board Secretariat","Trainee — systemic risk analysis","Systemic-risk monitoring and analytical support across banking, sovereign exposures, real estate, insurance, pensions and financial markets."]
];

const careerHtml = career.map(x => `<div class="career"><div class="period">${x[0]}</div><h3>${x[1]}</h3><strong>${x[2]}</strong><p class="muted">${x[3]}</p></div>`).join("");

await page("/", "Nikolas Mayer — Economist", "Nikolas Mayer is a Czech economist with experience at the European Central Bank, European Commission and European Parliament.", `
<section class="hero"><div class="container"><p class="eyebrow">Economics · Financial markets · European policy</p>
<h1>Economist working across central banking, markets and European policy.</h1>
<p class="lead">Nikolas Mayer is a Czech economist with professional experience at the European Central Bank, European Commission and European Parliament. His work has covered financial markets, banking supervision, macroprudential policy, macroeconomic forecasting, public finances and EU economic legislation.</p>
<a class="button" href="/career/">View career</a></div></section>
<section class="section"><div class="container grid2"><div><p class="eyebrow">Profile</p><h2>A career across European economic institutions</h2></div><div><p class="lead">My work has moved from financial-market and supervisory data to macroprudential policy, macroeconomic surveillance and EU legislative analysis.</p><p>This site is being built as a factual source of record: career history, selected projects, publications, public analysis and direct links to primary institutional sources.</p></div></div></section>
<section class="section"><div class="container"><p class="eyebrow">Selected experience</p>${careerHtml.slice(0, careerHtml.length)}</div></section>
<section class="section"><div class="container"><p class="eyebrow">Expertise</p><div class="grid3">
<div class="card"><h3>Macroeconomic policy</h3><p>Forecasting, fiscal policy, country surveillance and EU economic governance.</p></div>
<div class="card"><h3>Financial markets</h3><p>Sovereign bonds, FX markets, market operations and monetary-policy transmission.</p></div>
<div class="card"><h3>Banking & financial stability</h3><p>Supervisory data, macroprudential policy and financial-services regulation.</p></div>
</div></div></section>`);

await page("/about/", "About — Nikolas Mayer", "Biography of Czech economist Nikolas Mayer.", `
<section class="hero"><div class="container"><p class="eyebrow">About</p><h1>Economic analysis across institutions, markets and policy.</h1><p class="lead">Nikolas Mayer is a Czech economist whose career has spanned central banking, financial-market analysis, banking supervision, macroeconomic surveillance and European policy.</p></div></section>
<section class="section"><div class="container grid2"><div><h2>Background</h2></div><div><p>He studied Government and Economics at the London School of Economics and Quantitative Economics and Finance at the University of St. Gallen.</p><p>His professional experience includes the European Central Bank, European Commission, European Parliament and European Systemic Risk Board Secretariat.</p></div></div></section>`);

await page("/career/", "Career — Nikolas Mayer", "Professional experience of Nikolas Mayer at European economic institutions.", `
<section class="hero"><div class="container"><p class="eyebrow">Career</p><h1>Professional experience</h1><p class="lead">Selected roles across European central banking, financial supervision, macroeconomic policy and EU legislation.</p></div></section>
<section class="section"><div class="container">${careerHtml}</div></section>`);

await page("/publications/", "Publications — Nikolas Mayer", "Research and institutional publications by or involving Nikolas Mayer.", `
<section class="hero"><div class="container"><p class="eyebrow">Publications</p><h1>Research and institutional analysis.</h1><p class="lead">This section will contain verified ECB, European Commission and academic publications, with exact authorship, contribution type and links to primary records.</p></div></section>
<section class="section"><div class="container"><div class="card"><h3>Verification first</h3><p>Items will be added only after their bibliographic record and authorship or contribution status have been checked against the original institutional or academic source.</p></div></div></section>`);

await page("/videos/", "Public analysis — Nikolas Mayer", "Public economic analysis and videos by Nikolas Mayer.", `
<section class="hero"><div class="container"><p class="eyebrow">Public analysis</p><h1>Economic data explained for a broader audience.</h1><p class="lead">Selected short-form videos will become durable pages with searchable transcripts, charts and direct links to primary sources.</p></div></section>
<section class="section"><div class="container grid3">
<div class="card"><h3>Czech economy & foreign ownership</h3><p>FDI, profit flows, industrial structure and the Czech economic model.</p></div>
<div class="card"><h3>Central banking & markets</h3><p>Bond markets, central-bank operations, banking policy and financial stability.</p></div>
<div class="card"><h3>EU economic policy</h3><p>EU budget, recovery funding, fiscal policy and financial legislation.</p></div>
</div></section>`);

const csHead = `<!doctype html><html lang="cs"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Nikolas Mayer — ekonom</title><meta name="description" content="Nikolas Mayer je český ekonom se zkušenostmi z ECB, Evropské komise a Evropského parlamentu."><meta name="robots" content="noindex,follow"><link rel="canonical" href="https://nikolasmayer.com/cs/"><style>${css}</style></head><body>
<nav class="nav"><div class="container navin"><a class="brand" href="/cs/">Nikolas Mayer</a><div class="links"><a href="/">English</a><a href="/career/">Kariéra</a><a href="/publications/">Publikace</a><a href="/videos/">Analýzy</a></div></div></nav><main>`;
const csDir = new URL("./dist/cs/", import.meta.url);
await mkdir(csDir,{recursive:true});
await writeFile(new URL("index.html",csDir), csHead + `
<section class="hero"><div class="container"><p class="eyebrow">Ekonomie · Finanční trhy · Evropská politika</p>
<h1>Ekonom se zkušenostmi z centrálního bankovnictví, finančních trhů a evropské hospodářské politiky.</h1>
<p class="lead">Nikolas Mayer je český ekonom s profesní zkušeností z Evropské centrální banky, Evropské komise a Evropského parlamentu. Ve své práci se věnoval finančním trhům, bankovnímu dohledu, makroobezřetnostní politice, makroekonomickým prognózám, veřejným financím a evropské ekonomické legislativě.</p></div></section>
<section class="section"><div class="container"><p>Česká část webu bude postupně doplněna o kariéru, publikace, veřejné analýzy, zdroje a přepisy vybraných videí.</p></div></section>` + foot);

await writeFile(new URL("./dist/robots.txt", import.meta.url), `User-agent: *\nAllow: /\n`);
await writeFile(new URL("./dist/sitemap.xml", import.meta.url), `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${["/","/about/","/career/","/publications/","/videos/","/cs/"].map(p=>`<url><loc>https://nikolasmayer.com${p}</loc></url>`).join("\n")}\n</urlset>\n`);

console.log("Built static website successfully.");
console.log("Generated: /, /about/, /career/, /publications/, /videos/, /cs/, robots.txt, sitemap.xml");
