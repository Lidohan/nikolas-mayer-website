export const siteConfig = {
  name: 'Nikolas Mayer',
  title: 'Nikolas Mayer — Economist',
  description:
    'Official professional website of Nikolas Mayer, a Czech economist with experience at the European Central Bank, European Commission and European Parliament.',
  canonicalUrl: 'https://nikolasmayer.com',
  email: '',
  theme: 'editorial' as 'editorial' | 'minimal' | 'markets',
  preview: true,
  social: {
    linkedin: '',
    facebook: '',
    instagram: '',
    tiktok: '',
    youtube: ''
  },
  externalProfiles: {
    euWhoIsWho: '',
    orcid: '',
    googleScholar: ''
  }
};
