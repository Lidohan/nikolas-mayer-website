export const profile = {
  en: {
    eyebrow: 'Economics · Financial markets · European policy',
    heroTitle: 'Economist working across central banking, markets and European policy.',
    heroText:
      'Nikolas Mayer is a Czech economist with professional experience at the European Central Bank, European Commission and European Parliament. His work has covered financial markets, banking supervision, macroprudential policy, macroeconomic forecasting, public finances and EU economic legislation.',
    currentFocus:
      'He also publishes short-form videos and commentary explaining economic data, European policy and financial issues to a broader audience.',
    aboutTitle: 'A career across European economic institutions',
    aboutLead:
      'My work has moved from financial-market and supervisory data to macroprudential policy, macroeconomic surveillance and EU legislative analysis.',
    expertise: [
      'European economic and fiscal policy',
      'Macroeconomic forecasting and country analysis',
      'Sovereign bond and foreign-exchange markets',
      'Central-bank market operations and monetary-policy transmission',
      'Banking supervision and supervisory statistics',
      'Macroprudential policy and financial stability',
      'EU financial-services regulation',
      'EU budget, MFF, NextGenerationEU and the RRF'
    ],
    education: [
      {
        institution: 'London School of Economics and Political Science',
        qualification: 'BSc Government and Economics',
        dates: '2010–2013',
        detail: 'Upper Second Class Honours.'
      },
      {
        institution: 'University of St. Gallen',
        qualification: 'MA HSG Quantitative Economics and Finance',
        dates: '2013–2016',
        detail: 'Graduate work included quantitative GDP forecasting using Bayesian VAR and neural-network approaches.'
      }
    ],
    career: [
      {
        period: '2025–present',
        organisation: 'European Parliament',
        role: 'Administrator / economic and budgetary policy adviser',
        summary:
          'Economic, financial-services and budgetary policy work, including legislative analysis, briefings, amendments and assessment of European Commission proposals.',
        projects: [
          'Market Integration and Supervision Package: market integration, simplification, supervisory architecture and proportionality.',
          'Banking-sector competitiveness, Banking Union and financial-services legislation.',
          'Digital-euro and other economic and monetary policy files.',
          'EU budget, Multiannual Financial Framework, NextGenerationEU and related instruments.'
        ]
      },
      {
        period: 'Jun 2022–Apr 2025',
        organisation: 'European Commission — DG ECFIN',
        role: 'Economic Analyst — Czech Republic, Poland and Slovakia',
        summary:
          'Macroeconomic forecasting, country surveillance, fiscal analysis and Recovery and Resilience Facility work for Central European economies.',
        projects: [
          'Macroeconomic forecasts covering growth, inflation, labour markets and public finances.',
          'Assessment of national budgetary measures and fiscal developments.',
          'Economic surveillance and country-desk analysis for Czechia, Poland and Slovakia.',
          'Recovery and Resilience Facility analysis, including work around payment requests and implementation of national plans.'
        ]
      },
      {
        period: 'Feb 2021–Jun 2022',
        organisation: 'European Central Bank',
        role: 'Financial Stability / Macroprudential Policy Analyst',
        summary:
          'Analysis of macroprudential policy, bank resilience, lending behaviour and the interaction between capital requirements and credit conditions.',
        projects: [
          'Macroprudential capital buffers and their potential effects on bank lending.',
          'Analysis using AnaCredit loan-level data and COREP/FINREP banking data.',
          'Macro-financial risk monitoring and banking-system resilience.'
        ]
      },
      {
        period: 'Jul 2019–Feb 2021',
        organisation: 'European Central Bank',
        role: 'Market Operations Analyst — Bond and International Markets',
        summary:
          'Sovereign bond, foreign-exchange and international market analysis, with work on market conditions relevant to monetary-policy implementation and reserve management.',
        projects: [
          'Sovereign bond markets, yield curves, liquidity and investor behaviour.',
          'Market analysis during the APP and PEPP asset-purchase programmes.',
          'Foreign-exchange and foreign-reserve strategy, risk and performance analysis.',
          'Market briefings using Bloomberg, Python and Tableau.'
        ]
      },
      {
        period: 'Jul 2016–Jun 2019',
        organisation: 'European Central Bank',
        role: 'Supervisory Data Research Analyst',
        summary:
          'Supervisory banking data, data-quality processes and analytical work within the Single Supervisory Mechanism environment.',
        projects: [
          'COREP, FINREP, ALMM and supervisory benchmarking data flows with national authorities, the EBA and supervisory teams.',
          'RIAD reference/master-data work and supervisory data-quality controls.',
          'Automated extraction and analysis using Python, SAS, VBA and Access.',
          'Tableau dashboards and analysis of credit- and market-risk indicators.'
        ]
      },
      {
        period: 'Jul 2015–Jul 2016',
        organisation: 'European Systemic Risk Board Secretariat',
        role: 'Trainee — systemic risk analysis',
        summary:
          'Systemic-risk monitoring and analytical support across banking, sovereign exposures, real estate, insurance, pensions and financial markets.',
        projects: [
          'Systemic-risk monitoring and quantitative analysis.',
          'Banking and financial databases, including MATLAB-based analysis.',
          'Preparation of notes and presentations for policy discussions.'
        ]
      },
      {
        period: '2014–2015',
        organisation: 'European Commission — DG ECFIN',
        role: 'Trainee',
        summary: 'Early experience in European economic policy and country analysis.',
        projects: []
      },
      {
        period: '2013',
        organisation: 'Boston Consulting Group',
        role: 'Visiting Associate',
        summary: 'Strategy consulting experience.',
        projects: []
      },
      {
        period: '2012–2013',
        organisation: 'Arthur D. Little',
        role: 'Research Analyst / intern',
        summary: 'Research and analytical work in consulting.',
        projects: []
      },
      {
        period: '2011',
        organisation: 'Permanent Representation of the Czech Republic to the EU',
        role: 'Intern / financial-services support',
        summary: 'Early exposure to EU financial-services and policy work.',
        projects: []
      }
    ],
    videoThemes: [
      {
        title: 'The Czech economy, foreign ownership and dividend outflows',
        text: 'Data-driven explanations of foreign direct investment, profit flows, industrial structure and the long-running debate over the Czech economic model.'
      },
      {
        title: 'Privatisation, ownership and Czech companies',
        text: 'Historical and economic analysis of privatisation, foreign acquisitions and the ownership of major Czech companies and consumer brands.'
      },
      {
        title: 'Wages, productivity and the “assembly economy” debate',
        text: 'Comparisons of Czech wages, industrial employment, productivity and investment with Western European economies.'
      },
      {
        title: 'Central banking, markets and financial stability',
        text: 'Explanations of bond markets, central-bank operations, banking policy and how financial-market mechanisms affect the wider economy.'
      },
      {
        title: 'EU economic policy and public finances',
        text: 'The EU budget, recovery funding, fiscal policy, financial legislation and the economic choices behind European policy debates.'
      },
      {
        title: 'AI, markets and data-driven public debates',
        text: 'Short-form analysis of AI valuations, market risk and other economic questions where primary data and institutional research can clarify the debate.'
      }
    ]
  },
  cs: {
    eyebrow: 'Ekonomie · Finanční trhy · Evropská politika',
    heroTitle: 'Ekonom se zkušenostmi z centrálního bankovnictví, finančních trhů a evropské hospodářské politiky.',
    heroText:
      'Nikolas Mayer je český ekonom s profesní zkušeností z Evropské centrální banky, Evropské komise a Evropského parlamentu. Ve své práci se věnoval finančním trhům, bankovnímu dohledu, makroobezřetnostní politice, makroekonomickým prognózám, veřejným financím a evropské ekonomické legislativě.',
    currentFocus:
      'Na sociálních sítích publikuje krátká videa a komentáře, ve kterých vysvětluje ekonomická data, evropskou politiku a finanční témata širšímu publiku.',
    aboutTitle: 'Kariéra napříč evropskými ekonomickými institucemi',
    aboutLead:
      'Moje práce se postupně posunula od analýzy finančních trhů a dohledových dat k makroobezřetnostní politice, makroekonomickému dohledu a evropské legislativě.',
    expertise: [
      'Evropská hospodářská a fiskální politika',
      'Makroekonomické prognózy a analýza zemí',
      'Dluhopisové a devizové trhy',
      'Operace centrálních bank a transmise měnové politiky',
      'Bankovní dohled a dohledová statistika',
      'Makroobezřetnostní politika a finanční stabilita',
      'Regulace finančních služeb EU',
      'Rozpočet EU, VFR, NextGenerationEU a RRF'
    ]
  }
};
