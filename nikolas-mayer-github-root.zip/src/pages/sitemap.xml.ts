import type { APIRoute } from 'astro';
import { siteConfig } from '../config';

const routes = [
  '/', '/about/', '/career/', '/publications/', '/videos/',
  '/cs/', '/cs/o-mne/', '/cs/kariera/', '/cs/publikace/', '/cs/videa/'
];

export const GET: APIRoute = () => {
  const urls = routes.map((route) => `<url><loc>${siteConfig.canonicalUrl}${route}</loc></url>`).join('');
  const body = `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${urls}</urlset>`;
  return new Response(body, { headers: { 'Content-Type': 'application/xml; charset=utf-8' } });
};
